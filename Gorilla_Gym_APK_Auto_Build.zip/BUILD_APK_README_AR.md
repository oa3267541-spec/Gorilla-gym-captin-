# بناء APK تلقائي - Gorilla Gym

## أسهل طريقة على Windows
اضغط مرتين على:

`BUILD_APK.bat`

وسيتم بناء نسخة Release باسم:

`APK/GorillaGym.apk`

> لازم يكون Gradle وAndroid SDK مثبتين على الجهاز إذا لم يكن Gradle Wrapper موجودًا.

## Linux / macOS
شغّل:

`./BUILD_APK.sh`

وسيظهر الملف في:

`APK/GorillaGym.apk`

## بناء تلقائي على GitHub
يوجد Workflow في:

`.github/workflows/build-apk.yml`

بعد رفع المشروع إلى GitHub، يمكن تشغيل **Actions → Build Gorilla Gym APK → Run workflow**، وبعد انتهاء البناء يتم تنزيل `GorillaGym-APK` من Artifacts.

## رابط التطبيق
التطبيق مضبوط مسبقًا على:

https://roaring-centaur-440b93.netlify.app/payment.html?plan=month
